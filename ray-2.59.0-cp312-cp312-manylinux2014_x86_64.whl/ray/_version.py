# Replaced with the current commit when building the wheels.
commit = "dd83c3a703a5422d0b47f142cb380c6330817608"
version = "2.59.0"

if __name__ == "__main__":
    print("%s %s" % (version, commit))
