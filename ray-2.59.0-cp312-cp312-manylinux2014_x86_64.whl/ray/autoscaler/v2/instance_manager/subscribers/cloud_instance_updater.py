import logging
import uuid
from collections import defaultdict
from typing import List, Optional

from ray.autoscaler.v2.instance_manager.instance_manager import (
    InstanceUpdatedSubscriber,
)
from ray.autoscaler.v2.instance_manager.node_provider import ICloudInstanceProvider
from ray.autoscaler.v2.metrics_reporter import AutoscalerMetricsReporter
from ray.core.generated.instance_manager_pb2 import Instance, InstanceUpdateEvent

logger = logging.getLogger(__name__)


class CloudInstanceUpdater(InstanceUpdatedSubscriber):
    """CloudInstanceUpdater is responsible for launching
    new instances and terminating cloud instances

    It requests the cloud instance provider to launch new instances when
    there are new instance requests (with REQUESTED status change).

    It requests the cloud instance provider to terminate instances when
    there are new instance terminations (with TERMINATING status change).

    The cloud instance APIs are async and non-blocking.
    """

    def __init__(
        self,
        cloud_provider: ICloudInstanceProvider,
        metrics_reporter: Optional[AutoscalerMetricsReporter] = None,
    ) -> None:
        self._cloud_provider = cloud_provider
        self._metrics_reporter = metrics_reporter

    def notify(self, events: List[InstanceUpdateEvent]) -> None:
        new_requests = [
            event for event in events if event.new_instance_status == Instance.REQUESTED
        ]
        new_terminations = [
            event
            for event in events
            if event.new_instance_status == Instance.TERMINATING
        ]
        terminated_instances = [
            event
            for event in events
            if event.new_instance_status == Instance.TERMINATED
            and event.cloud_instance_id
        ]
        self._launch_new_instances(new_requests)
        self._terminate_instances(new_terminations)
        self._count_stopped_instances(terminated_instances)

    def _terminate_instances(self, new_terminations: List[InstanceUpdateEvent]) -> None:
        """
        Terminate cloud instances through cloud provider.

        Args:
            new_terminations: List of new instance terminations.
        """
        if not new_terminations:
            logger.debug("No instances to terminate.")
            return

        # Terminate each cloud instance at most once. Multiple instance manager
        # records can refer to the same cloud instance after a raylet restart.
        cloud_instance_ids = list(
            dict.fromkeys(
                event.cloud_instance_id
                for event in new_terminations
                if event.cloud_instance_id
            )
        )
        if not cloud_instance_ids:
            return

        # This is an async call.
        self._cloud_provider.terminate(
            ids=cloud_instance_ids, request_id=str(uuid.uuid4())
        )

    def _count_stopped_instances(self, terminated_instances: List[InstanceUpdateEvent]):
        """
        Record successfully terminated cloud instances.

        Args:
            terminated_instances: List of terminated cloud instances.

        Returns:
            None.
        """
        if not terminated_instances or not self._metrics_reporter:
            return

        self._metrics_reporter.inc_stopped_nodes(len(terminated_instances))

    def _launch_new_instances(self, new_requests: List[InstanceUpdateEvent]) -> None:
        """
        Launches new instances by requesting the cloud provider.

        Args:
            new_requests: List of new instance requests.

        """
        if not new_requests:
            logger.debug("No instances to launch.")
            return

        # Group new requests by launch request id.
        requests_by_launch_request_id = defaultdict(list)

        for event in new_requests:
            assert (
                event.launch_request_id
            ), "Launch request id should have been set by the reconciler"
            requests_by_launch_request_id[event.launch_request_id].append(event)

        for launch_request_id, events in requests_by_launch_request_id.items():
            request_shape = defaultdict(int)
            for event in events:
                request_shape[event.instance_type] += 1
            # Make requests to the cloud provider.
            self._cloud_provider.launch(
                shape=request_shape, request_id=launch_request_id
            )
